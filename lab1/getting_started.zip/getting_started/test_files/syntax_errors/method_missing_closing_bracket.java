public class Factorial{
    public static void main(String[] a){
    }
}

class Element {
    public boolean Init(){
        Age = v_Age ;
        return true;
    

}
